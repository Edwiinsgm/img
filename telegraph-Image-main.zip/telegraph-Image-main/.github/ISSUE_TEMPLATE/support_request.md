---
name: Support Request
about: 寻求帮助或支持
title: "[Support] 简要描述支持请求"
labels: question
assignees: ''
---

### 你的问题

<!-- 请详细描述你遇到的问题或需要帮助的地方。 -->

### 你已尝试的解决方案

<!-- 请描述你为解决问题所尝试过的方法。 -->

### 环境信息

- 操作系统: [e.g. Windows 10, macOS 11]
- 浏览器: [e.g. Chrome 92, Firefox 89]


### 附加信息

<!-- 任何你认为与支持请求相关的其他信息。 -->
